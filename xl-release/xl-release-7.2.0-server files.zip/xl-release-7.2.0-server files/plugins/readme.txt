Put your XL Release plugin JARs in this directory.
