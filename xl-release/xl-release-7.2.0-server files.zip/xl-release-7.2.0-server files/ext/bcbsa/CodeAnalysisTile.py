import json
from xlrelease.HttpRequest import HttpRequest

try:
    f = open("/opt/xebialabs/xl-release/xl-release-7.2.0-server/ext/bcbsa/webservice_url.txt", "r")
    try:
        address = f.read()
    finally:
        f.close()
except IOError:
    raise Exception("Could not read webservice_url.txt")

url = "/codeanalysisstatus"
request = HttpRequest({"url": address.strip()})
response = request.get(url, contentType='application/json')

if response.status != 200:
    raise Exception("Request to GitHub failed with status %s, response %s" % (response.status, response.response))

codeanalysisstatusinfo = json.loads(response.response)

data = {
    "codeanalysisstatus": codeanalysisstatusinfo
}
