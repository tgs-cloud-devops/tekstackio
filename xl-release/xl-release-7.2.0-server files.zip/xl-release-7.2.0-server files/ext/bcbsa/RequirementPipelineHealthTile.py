import json
import urllib2
import os
from threading import Thread

global requirement_epics
requirement_epics = []

class requirement_health_thread(Thread):
    def __init__(self, releaseName, authorization, urlAddress, urlParameters):
        Thread.__init__(self)
	self.releaseName = releaseName 
	self.authorization = authorization
	self.urlAddress = urlAddress
	self.urlParameters = urlParameters

    def run(self):
        global requirement_epics
        epics = []

        headers = {'content-type': 'application/json', 'Authorization': self.authorization}
        epicresults = getdata( self.urlAddress + self.urlParameters, headers )

        for key in epicresults['QueryResult']['Results']:
            getfeatures(str(key['FormattedID']), str(key['Name']), epics, str(key['Children']['_ref']), self.releaseName)

	data = {
    	    "epics": epics
	}

	rel = self.releaseName
	data_file = "/opt/xebialabs/xl-release/xl-release-7.2.0-server/ext/bcbsa/data/" + rel.replace(" ", "") + "_requirement_health.json"
	#write epics to a file
	with open(data_file, 'w') as outfile:  
            json.dump(data, outfile)
	
def getdata( url, headers = {} ):
    req = urllib2.Request(url, headers = headers)

    try:
        resp = urllib2.urlopen(req)
    except urllib2.HTTPError, e:
        raise Exception("Request to %s failed with error %s" % (url , str(e.code)))
    except urllib2.URLError, e:
        raise Exception("Request to %s failed with URLError =  %s" % (url , str(e.reason)))
    except httplib.HTTPException, e:
        raise Exception("Request to %s failed with HTTPException" % (url))
    except Exception:
        raise Exception("Request to %s failed with Exeption" % (url))

    respData = resp.read()

    return  json.loads(respData)

def getfeatures( epic_id, epic_name, epics, url, release ):
    headers = {'content-type': 'application/json', 'Authorization': 'Basic aWFzYWxhemFyQHRla3N5c3RlbXMuY29tOnBhbmNobzEyMw=='}
    queryresults = getdata( url, headers )
   
    for key in queryresults['QueryResult']['Results']: # get the features for the given Epic
        Total = 0
        Undefined = 0
        Defined = 0
        dict = {'Epic': '', 'EpicName': '', 'Feature': '', 'FeatureName': '', 'Owner': '', 'Status': 'Green', 'TotalUserStories': 0,
                'UndefinedUserStories': 0, 'DefinedUserStories': 0, 'Release': ''}

        dict['Epic'] = epic_id
        dict['EpicName'] = epic_name
        dict['Feature'] = str(key['FormattedID'])
        dict['FeatureName'] = str(key['Name'])

	if key['Release']:
            dict['Release'] = str(key['Release']['_refObjectName'])
	else:
	    dict['Release'] = 'Unassigned'

        if key['Owner']:
            dict['Owner'] = key['Owner']['_refObjectName']
        else:
            dict['Owner'] = 'Unassigned'

	if dict['Release'] == release:
            Total, Undefined, Defined = getuserstoryinfo(key['UserStories']['_ref']) # get the user stories for the given feature

            dict['TotalUserStories'] = Total
            dict['UndefinedUserStories'] = Undefined
            dict['DefinedUserStories'] = Defined

            epics.append(dict)

def getuserstoryinfo(url):
    count = 0
    undefined = 0
    defined = 0
    headers = {'content-type': 'application/json', 'Authorization': 'Basic aWFzYWxhemFyQHRla3N5c3RlbXMuY29tOnBhbmNobzEyMw=='}

    queryresults = getdata( url, headers )

    for key in queryresults['QueryResult']['Results']:
        count = count + 1

        if key['FlowState']['_refObjectName'] == 'Defined':
            defined = defined + 1

        if key['FlowState']['_refObjectName'] == 'Undefined':
            undefined = undefined + 1

    return count, undefined, defined

###### Main ######
data = {
    "epics": []
}

t1 = requirement_health_thread(releaseName, authorization, urlAddress, urlParameters)
t1.start()
rel = releaseName
data_file = "/opt/xebialabs/xl-release/xl-release-7.2.0-server/ext/bcbsa/data/" + rel.replace(" ", "") + "_requirement_health.json"

if os.path.exists(data_file):
    with open(data_file) as json_file:  
        data = json.load(json_file)
