import json
from xlrelease.HttpRequest import HttpRequest

key = '5TbhnhZWTJ6p0YeLY7IzdnBFtRXC4kHCgbOVeNDyREg'
pagesize = 100
fetch = 'true'
query = 'query=(Release.Name%20=%20"2017%20Release%204")'
headers = {'content-type': 'application/json', 'Authorization': 'Basic aWFuLnNhbGF6YXIuY3NAYmNic2EuY29tOk5vdmVtYmVyMTIz'}
address = 'https://rally1.rallydev.com'
params = '/slm/webservice/v2.0/portfolioitem/directionalepic?key=' + key + '&fetch=' + fetch + '&start=1&pagesize=' + str(pagesize) + '&' + query
request = HttpRequest({"url": address})
response = request.get(params, headers=headers)

if response.status != 200:
    raise Exception("Request to %s failed with status %s, response %s" % (address.strip() + url , response.status, response.response))

epicstatus = json.loads(response.response)

data = {
    "epicstatus": epicstatus
}
