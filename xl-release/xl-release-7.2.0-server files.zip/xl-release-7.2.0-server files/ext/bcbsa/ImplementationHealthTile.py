import json
import urllib2
import os
from threading import Thread

global implementation_epics
implementation_epics = []

class implementation_health_thread(Thread):
    def __init__(self, releaseName, authorization, urlAddress, urlParameters):
        Thread.__init__(self)
        self.releaseName = releaseName
        self.authorization = authorization
        self.urlAddress = urlAddress
        self.urlParameters = urlParameters

    def run(self):
        global implementation_epics
        epics = []
        headers = {'content-type': 'application/json', 'Authorization': self.authorization}
        epicresults = getdata( self.urlAddress + self.urlParameters, headers )

        for key in epicresults['QueryResult']['Results']:
            getfeatures(str(key['FormattedID']), str(key['Name']), epics, str(key['Children']['_ref']), self.releaseName)

        data = {
            "epics": epics
        }

        rel = self.releaseName
        data_file = "/opt/xebialabs/xl-release/xl-release-7.2.0-server/ext/bcbsa/data/" + rel.replace(" ", "") + "_implementation_health.json"
        #write epics to a file
        with open(data_file, 'w') as outfile:
            json.dump(data, outfile)

def getdata( url, headers = {} ):
    req = urllib2.Request(url, headers = headers)

    try:
        resp = urllib2.urlopen(req)
    except urllib2.HTTPError, e:
        raise Exception("Request to %s failed with error %s" % (url , str(e.code)))
    except urllib2.URLError, e:
        raise Exception("Request to %s failed with URLError =  %s" % (url , str(e.reason)))
    except httplib.HTTPException, e:
        raise Exception("Request to %s failed with HTTPException" % (url))
    except Exception:
        raise Exception("Request to %s failed with Exeption" % (url))

    respData = resp.read()

    return  json.loads(respData)

def getfeatures( epic_id, epic_name, epics, url, release ):
    headers = {'content-type': 'application/json', 'Authorization': 'Basic aWFzYWxhemFyQHRla3N5c3RlbXMuY29tOnBhbmNobzEyMw=='}
    queryresults = getdata( url, headers )

    for key in queryresults['QueryResult']['Results']:
        Total = 0
        Defined = 0
        InProgress = 0
	Demoed = 0
	dict = {'Epic': '', 'EpicName': '', 'Feature': '', 'FeatureName': '', 'Owner': '', 'Status': 'Green', 'TotalUserStories': 0,
		'DefinedUserStories': 0, 'UserStoriesInProgress': 0, 'DemoedUserStories': 0, 'Release': ''}

        dict['Epic'] = epic_id
        dict['EpicName'] = epic_name
        dict['Feature'] = str(key['FormattedID'])
        dict['FeatureName'] = str(key['Name'])

	if key['Release']:
            dict['Release'] = str(key['Release']['_refObjectName'])
        else:
            dict['Release'] = 'Unassigned'

        if key['Owner']:
            dict['Owner'] = key['Owner']['_refObjectName']
        else:
            dict['Owner'] = 'Unassigned'

        if dict['Release'] == release:
            Total, Defined, InProgress, Demoed = getuserstoryinfo(key['UserStories']['_ref'])

            dict['TotalUserStories'] = Total
            dict['DefinedUserStories'] = Defined
            dict['UserStoriesInProgress'] = InProgress
	    dict['DemoedUserStories'] = Demoed

            epics.append(dict)

def getuserstoryinfo(url):
    count = 0
    defined = 0
    inprogress = 0
    demoed = 0
    headers = {'content-type': 'application/json', 'Authorization': 'Basic aWFzYWxhemFyQHRla3N5c3RlbXMuY29tOnBhbmNobzEyMw=='}

    queryresults = getdata( url, headers )

    for key in queryresults['QueryResult']['Results']:
        count = count + 1

        if key['FlowState']['_refObjectName'] == 'Defined':
            defined = defined + 1

        if key['FlowState']['_refObjectName'] == 'In-Progress':
            inprogress = inprogress + 1

	if key['FlowState']['_refObjectName'] == 'Accepted':
            demoed = demoed + 1

    return count, defined, inprogress, demoed

######## Main #######
data = {
    "epics": []
}

#raise Exception("Release name= %s,  authorization= %s, URL= %s, Params= %s " % (releaseName, authorization, urlAddress, urlParameters))

t1 = implementation_health_thread(releaseName, authorization, urlAddress, urlParameters)
t1.start()
rel = releaseName
data_file = "/opt/xebialabs/xl-release/xl-release-7.2.0-server/ext/bcbsa/data/" + rel.replace(" ", "") + "_implementation_health.json"

if os.path.exists(data_file):
    with open(data_file) as json_file:
        data = json.load(json_file)

