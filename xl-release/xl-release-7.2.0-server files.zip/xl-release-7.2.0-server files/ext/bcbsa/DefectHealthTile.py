defectdata = [
                {'EpicName': 'Epic 1', 'FeatureName': 'Feature 1', 'Owner': 'John Doe', 'DefectsLogged': 5, 'DefectsOpen': 0, 'DefectsResolved': 0, 'DefectsClosed': 5},
                {'EpicName': 'Epic 1', 'FeatureName': 'Feature 2', 'Owner': 'John Doe', 'DefectsLogged': 1, 'DefectsOpen': 1, 'DefectsResolved': 0, 'DefectsClosed': 0},
                {'EpicName': 'Epic 1', 'FeatureName': 'Feature 3', 'Owner': 'John Doe', 'DefectsLogged': 1, 'DefectsOpen': 0, 'DefectsResolved': 0, 'DefectsClosed': 1},
                {'EpicName': 'Epic 2', 'FeatureName': 'Feature 1', 'Owner': 'Jane Doe', 'DefectsLogged': 3, 'DefectsOpen': 1, 'DefectsResolved': 0, 'DefectsClosed': 0},
                {'EpicName': 'Epic 2', 'FeatureName': 'Feature 2', 'Owner': 'Jane Doe', 'DefectsLogged': 7, 'DefectsOpen': 0, 'DefectsResolved': 5, 'DefectsClosed': 2}
]

data = {
    "epics": defectdata
}
