import json
import urllib2

def gettestresultinfo(tests):
    testcount = 0
    Passed = 0
    Failed = 0
    Skipped = 0

    for key in tests:
        testcount += 1

        if key['result']['status'] == 'passed':
            Passed += 1

        if key['result']['status'] == 'failed':
            Failed += 1

        if key['result']['status'] == 'skipped':
            Skipped += 1

    return testcount, Passed, Failed, Skipped

def getuserstoryinfo(stories):
    StoryCount = 0
    TestCountTotal = 0
    PassedTotal = 0
    FailedTotal = 0
    SkippedTotal = 0

    for key in stories:

        print key
        if key['keyword'] == 'User Story':
            StoryCount += 1
            testcount, passed, failed, skipped = gettestresultinfo(key['steps'])
            TestCountTotal += testcount
            PassedTotal += passed
            FailedTotal += failed
            SkippedTotal += skipped

    return StoryCount, TestCountTotal, PassedTotal, FailedTotal, SkippedTotal

def getfeatures( epic_name, features, epics ):

    for key in features: # get the features for the given Epic
        TotalUserStories = 0
        TotalTestCases = 0
        TotalPassed = 0
        TotalFailed = 0
        TotalSkipped = 0
        dict = {'EpicName': '', 'FeatureName': '', 'Owner': '', 'TotalUserStories': 0,
                'TotalTestCases': 0, 'PassedTests': 0, 'FailedTests': 0, 'SkippedTests': 0}

        dict['EpicName'] = epic_name
        dict['FeatureName'] = str(key['name'])
        dict['Owner'] = 'John Doe'

        TotalUserStories, TotalTestCases, TotalPassed, TotalFailed, TotalSkipped = getuserstoryinfo(key['elements']) # get the user stories for the given feature

        dict['TotalUserStories'] = TotalUserStories
        dict['TotalTestCases'] = TotalTestCases
        dict['PassedTests'] = TotalPassed
        dict['FailedTests'] = TotalFailed
        dict['SkippedTests'] = TotalSkipped

        epics.append(dict)

def getdata( url, headers = {} ):
    req = urllib2.Request(url, headers = headers)

    try:
        resp = urllib2.urlopen(req)
    except urllib2.HTTPError, e:
        raise Exception("Request to %s failed with error %s" % (url , str(e.code)))
    except urllib2.URLError, e:
        raise Exception("Request to %s failed with URLError =  %s" % (url , str(e.reason)))
    except httplib.HTTPException, e:
        raise Exception("Request to %s failed with HTTPException" % (url))
    except Exception:
        raise Exception("Request to %s failed with Exeption" % (url))

    respData = resp.read()

    return  json.loads(respData)

##### Main #####
url = urlAddress # 'http://104.42.29.137/testresults/selenium'
queryresults = getdata(url)

epics = []
epicname = None
features = None

#iterate through the epics
for key, value in queryresults.iteritems():
    if key == 'epic':
        epicname = value

    if (key == 'featureArray'):
        features = value

    if epicname and features:
        getfeatures(epicname, features, epics)
        features = None
        epicname = None

data = {
    "epics": epics
}
